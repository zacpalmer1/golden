//
//  golden3App.swift
//  golden3
//
//  Created by Zac Palmer on 6/13/22.
//

import SwiftUI

@main
struct golden3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
